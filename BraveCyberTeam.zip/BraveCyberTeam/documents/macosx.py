R = '\033[31m' # Red
N = '\033[1;37m' # White
def a():
	print ""+N+""
	print "VIRUS FOR MACOSX COLLECTIONS"
	print "============================="
	print 
	print "name                                        rank"
	print "----                                        ----\033[31m"
	print "/modules/macosx/module_trinoids             not tested"
	print "/modules/macosx/module_nothing              not tested"
if __name__ == "__main__":
	a()
