# BraveCyberTeam
# (C)Copyright 2019 BRAVE CYBER TEAM
<br>
tools to make virus simple - GUNAKAN DENGAN HALUS DAN RAPIH PENUH KELEMBUTAN :)
<br>
$ git clone https://github.com/kastumjr420/BraveCyberTeam
<br>
$ cd BraveCyberTeam
<br>
$ sh install.sh
<br>
<br>
# Simple commands
<br>
vcrt > show options
<br>
<>
REPORT ME BUG ON INSTAGRAM
# Contact
<br>
instagram : @Official_sigit509
<br>
facebook : facebook.com/SigitCrostLazt
<br>
# Thanks to
# Brave Cyber Team
